# AutoBuilder package 
# Author: James Percent (james@empty-set.net)
__all__ = [auto_builder, manifest, dependencies, generator]

